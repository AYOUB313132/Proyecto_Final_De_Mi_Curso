export interface Curso {
  cursoId:          number;
  nombreCurso:      string;
  detallesDelCurso: string;
  fechaInicio:      Date;
  fechaFinal:       Date;
  profesorId:       number;
  precio:           number;
  tipo:             Tipo;
  imagen:           string;
}

export interface Tipo {
  tipoId:     number;
  tipoNombre: string;
  imagen: string;
}
