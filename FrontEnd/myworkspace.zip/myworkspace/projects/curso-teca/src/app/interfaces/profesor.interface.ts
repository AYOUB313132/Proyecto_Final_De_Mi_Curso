export interface Profesor {
  id:           number;
  nombre:       string;
  apellido:     string;
  imagen:       string;
  especialidad: string;
  linkTwitter:  string;
  linkLinkedin: string;
}
