
export interface Usuario {
  id:                    number;
  nombre:                string;
  apellido:              string;
  email:                 string;
  genero:                string;
  fechaNacimiento:       string;
  direccion:             string;
  movil:                 number;
  ciudad:                string;
  codigoPostal:          number;
  provincia:             string;
  pais:                  string;
  imagen:                string;
  role:                  string;

}

