export interface Blog {
  id:        number;
  titulo:    string;
  parrafo:   string;
  imagen:    string;
  descripcion:    string;
  fecha:     Date;
  categoria: Categoria;
}

export interface Categoria {
  id:     number;
  nombre: string;
}
