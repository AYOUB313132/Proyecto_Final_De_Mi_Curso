export interface Inscripcion {
  id:        number;
  cursoId:   number;
  usuarioId: number;
}
