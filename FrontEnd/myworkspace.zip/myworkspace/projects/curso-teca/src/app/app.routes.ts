import { ListaMiCursosComponent } from './components/paginas/lista-mi-cursos/lista-mi-cursos.component';
import { ListaCursosTipoComponent } from './components/paginas/lista-cursos-tipo/lista-cursos-tipo.component';
import { CursoDetallesComponent } from './components/curso-detalles/curso-detalles.component';
import { ModificarUsuarioPersonalComponent } from './components/dashboard/usuarios/modificar-usuario-personal/modificar-usuario-personal.component';
import { ModifUsuarioComponent } from './components/dashboard/usuarios/modif-usuario/modif-usuario.component';
import { ModificarBlogComponent } from './components/dashboard/blogs/modificar-blog/modificar-blog.component';
import { AddBlogComponent } from './components/dashboard/blogs/add-blog/add-blog.component';
import { ModificarTipoCursoComponent } from './components/dashboard/cursos/tipos-curso/modificar-tipo-curso/modificar-tipo-curso.component';
import { AddTipoCursoComponent } from './components/dashboard/cursos/tipos-curso/add-tipo-curso/add-tipo-curso.component';
import { ModificarCursoComponent } from './components/dashboard/cursos/modificar-curso/modificar-curso.component';
import { AddCursoComponent } from './components/dashboard/cursos/add-curso/add-curso.component';
import { AddProfesorComponent } from './components/dashboard/profesores/add-profesor/add-profesor.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { authDashboardAdminGuard } from './servicios/Redirecciones/auth-dashboard-admin.guard';
import { AdminDashboardComponent } from './components/dashboard/admin-dashboard/admin-dashboard.component';
import { QuinesSomosComponent } from './components/paginas/quines-somos/quines-somos.component';
import { CursosComponent } from './components/paginas/cursos/cursos.component';
import { ProfesoresComponent } from './components/paginas/profesores/profesores.component';
import { ContactoComponent } from './components/paginas/contacto/contacto.component';
import { InscripcionComponent } from './components/paginas/inscripcion/inscripcion.component';
import { LoginComponent } from './components/paginas/login/login.component';
import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { BlogComponent } from './components/paginas/blog/blog.component';
import { authGuard } from './servicios/Redirecciones/auth.guard';
import { authLoginGuard } from './servicios/Redirecciones/auth-login.guard';
import { ModificarProfesorComponent } from './components/dashboard/profesores/modificar-profesor/modificar-profesor.component';


export const routes: Routes = [
  {path: 'home', title: 'Home', component: HomeComponent},
  {path: 'login', title: 'Login', component: LoginComponent, canActivate: [authLoginGuard]},
  {path: 'registrame', title: 'Registrame', component: InscripcionComponent, canActivate: [authLoginGuard]},
  {path: 'blog', title: 'Blog', component: BlogComponent},
  {path: 'contacto', title: 'Contacto', component: ContactoComponent},
  {path: 'profesores', title: 'Profesores', component: ProfesoresComponent, canActivate: [authGuard]},
  {path: 'cursos', title: 'Cursos', component: CursosComponent, canActivate: [authGuard]},
  {path: 'curso-detalles/:id', title: 'Curso Detalles', component: CursoDetallesComponent, canActivate: [authGuard]},
  {path: 'lista-cursos-tipo/:id', title: 'Curso Tipo', component: ListaCursosTipoComponent, canActivate: [authGuard]},
  {path: 'lista-mi-cursos/:id', title: 'Lista mi cursos', component: ListaMiCursosComponent, canActivate: [authGuard]},

  {path: 'modificar-me-datos/:id', title: 'Modificar Me Datos', component: ModificarUsuarioPersonalComponent, canActivate: [authGuard]},

  {path: 'quines-somos', title: 'Quines Somos', component: QuinesSomosComponent},
  {path: 'admin-dashboard', title: 'Admin Dashboard', component: AdminDashboardComponent, canActivate: [authDashboardAdminGuard]},
  {path: 'admin-dashboard',  children : [
      {path: 'add-curso', title: 'Admin Dashboard | Añadir Cursos', component: AddCursoComponent, canActivate: [authDashboardAdminGuard]},
      {path: 'modificar-curso/:id', title: 'Admin Dashboard | Modificar Cursos', component: ModificarCursoComponent, canActivate: [authDashboardAdminGuard]},

      {path: 'modificar-usuario/:id', title: 'Admin Dashboard | Modificar Usuario', component: ModifUsuarioComponent, canActivate: [authDashboardAdminGuard]},

      {path: 'add-profesor', title: 'Curso Panel | Add Profesor', component: AddProfesorComponent},
      {path: 'modificar-profesor/:id', title: 'Admin Dashboard | Modificar Profesor', component: ModificarProfesorComponent, canActivate: [authDashboardAdminGuard]},

      {path: 'add-tipo-curso', title: 'Curso Panel | Add Tipo Curso', component: AddTipoCursoComponent},
      {path: 'modificar-tipo-curso/:id', title: 'Admin Dashboard | Modificar Tipo Curso', component: ModificarTipoCursoComponent, canActivate: [authDashboardAdminGuard]},

      {path: 'add-blog', title: 'Blog Panel | Add Blog', component: AddBlogComponent},
      {path: 'modificar-blog/:id', title: 'Admin Dashboard | Modificar Blog', component: ModificarBlogComponent, canActivate: [authDashboardAdminGuard]}
    ]
  },

  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: '**', component: PageNotFoundComponent}
];
