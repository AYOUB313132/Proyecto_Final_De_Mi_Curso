import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class AuthServiceService {

  URL:string = "http://localhost:8094/auth"

  constructor(private http:HttpClient) { }


  login(RequestResponse:any):Observable<any>{
    return this.http.post(this.URL + "/login", RequestResponse);
  }


  async register(RequestResponse:any):Promise<any>{

     return await firstValueFrom( this.http.post(this.URL + "/register", RequestResponse));
  }




}
