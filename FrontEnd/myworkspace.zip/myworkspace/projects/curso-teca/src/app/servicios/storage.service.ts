import { Injectable } from '@angular/core';


const TOKEN = "token-curso-teca";
const USER:string = "user-curso-teca";

@Injectable({
  providedIn: 'root'
})
export class StorageService {



  constructor() { }

   saveToken(tokenValue:string):void{
    window.localStorage.removeItem(TOKEN);
    window.localStorage.setItem(TOKEN, tokenValue);
  }

   saveUser(user:any):void{
    window.localStorage.removeItem(USER);
    window.localStorage.setItem(USER, JSON.stringify(user));
  }

   getToken(): any{
    return window.localStorage.getItem(TOKEN);
  }


   getUsuario():any {
    const useData =  localStorage.getItem(USER);
    if (useData){
      return JSON.parse(useData);
    }else{
      return null;
    }
  }

  getUsuarioId():string {
    const user = this.getUsuario();
    if(user == null)
      return ""
    return user.id
  }

   getUsuarioRole():string {
    const usuario = this.getUsuario();
    if(usuario == null)
      return "";
    return usuario.role;

  }

   isAdminLogged():boolean {
    if(this.getToken() == null)
      return false;
    const role:string = this.getUsuarioRole();
    if(role == "ADMIN"){
      return true;
    }else{
      return false
    }
  }


   isUsuarioLogged():boolean {
    if(this.getToken() == null)
      return false;
    const role:string = this.getUsuarioRole();
    if(role == "USER"){
      return true;
    }else{
      return false
    }
  }

   isProfesorLogged():boolean {
    if(this.getToken() == null)
      return false;
    const role:string = this.getUsuarioRole();
    if(role == "PROFESOR"){
      return true;
    }else{
      return false
    }
  }


   logout(): void {
    window.localStorage.removeItem(TOKEN);
    window.localStorage.removeItem(USER);
  }


}
