import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { StorageService } from '../storage.service';
import { Observable, firstValueFrom } from 'rxjs';
import { Profesor } from '../../interfaces/profesor.interface';
import { Curso, Tipo } from '../../interfaces/curso.interface';
import { Usuario } from '../../interfaces/usuario.interface';
import { Blog, Categoria } from '../../interfaces/blog.interface';
import { Inscripcion } from '../../interfaces/inscrepcion.interface';

@Injectable({
  providedIn: 'root'
})
export class AdminServicioService {

  private LINK_USUARIOS:string = "http://localhost:8094/usuarios"
  private LINK_PROFESORES:string = "http://localhost:8094/profesores"
  private LINK_CURSOS:string = "http://localhost:8094/cursos"
  private LINK_TIPOS_CURSOS:string = "http://localhost:8094/cursos/tipo-cursos"
  private LINK_IMAGENES:string = "http://localhost:8094/imagenes"
  private LINK_BLOGS:string = "http://localhost:8094/blogs"
  private LINK_CATEGORIA_BLOGS:string = "http://localhost:8094/blogs/categorias"
  private LINK_INSCREPCIONE:string = "http://localhost:8094/inscripciones"

  constructor(private http:HttpClient, private storage: StorageService) { }

  /* ========================= IMAGENES ========================= */

   añadirImagen(img:File){
    const headers = {
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    const formData = new FormData();
    formData.append('imagen', img);

   return this.http.post<any>(this.LINK_IMAGENES,formData, {
    headers: headers,
    reportProgress: true, // Si necesitas informes de progreso
    observe: 'events' // Si necesitas observar eventos
  })
  }

  /* ========================= USUARIOS ========================= */

  async getUsuarios(): Promise <any>{
    const headers = {
      //'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    let usuarios = await firstValueFrom(this.http.get<any>(this.LINK_USUARIOS, {headers} ));
    return usuarios.usuarios;
  }

  async addUsuario(usuario:Usuario): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom( this.http.post(this.LINK_USUARIOS, usuario,  {headers}))

  }

  async getUsuario(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_USUARIOS + "/" + id,  {headers} ))
  }

  async modificarUsuario(id:number, usuario:Usuario): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.put<any>(this.LINK_USUARIOS + "/" + id, usuario, {headers} ))
  }

  async setRoleUsuario(id:number, usuario:Usuario): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.put<any>(this.LINK_USUARIOS + "/setrole/" + id, usuario, {headers} ))
  }

  async borrarUsuario(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.delete<any>(this.LINK_USUARIOS + "/" + id, {headers} ))
  }

  async getCursosUsuario(id:number): Promise <any>{
    const headers = {
      //'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom(this.http.get<any>(this.LINK_USUARIOS + "/" + id + "/cursos", {headers} ));
  }

  async desinscribirUsuarioDeCurso(usuarioId:number, cursoId:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.delete<any>(this.LINK_USUARIOS + "/" + usuarioId + "/curso/" + cursoId, {headers} ))
  }


  /* ========================= CURSOS ========================= */

  async getCursos(): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_CURSOS, {headers}))
  }

  async addCurso(curso:Curso): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom( this.http.post(this.LINK_CURSOS, curso,  {headers}))
  }

  async getCurso(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_CURSOS + "/" + id,  {headers} ))
  }

  async modificarCurso(id:number, curso:Curso): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom( this.http.put<any>(this.LINK_CURSOS + "/" + id, curso, {headers} ))
  }

  async borrarCurso(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.delete<any>(this.LINK_CURSOS + "/" + id, {headers} ))
  }

  async getCursosDeTipo(id: number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_CURSOS + "/tipo/" + id, {headers}))
  }


  /* ========================= TIPO CURSOS ========================= */

  async getCursoTipos(): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom(this.http.get<any>(this.LINK_TIPOS_CURSOS, {headers}))
  }

  async getCursoTipo(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_TIPOS_CURSOS + "/" + id, {headers}))
  }

  async addTipoCurso(tipo:Tipo): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom( this.http.post(this.LINK_TIPOS_CURSOS, tipo,  {headers}))
  }

  async modificarTipoCurso(id:number, tipo:Tipo): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom( this.http.put<any>(this.LINK_TIPOS_CURSOS + "/" + id, tipo, {headers} ))
  }

  async borrarTipoCurso(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.delete<any>(this.LINK_TIPOS_CURSOS + "/" + id, {headers} ))
  }

  async getNumeroCursosDeCadaTipo(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_TIPOS_CURSOS + "/numero/" + id, {headers}))
  }
/*
getNumeroCursosDeCadaTipo(id:number):Observable<any>{
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + this.storage.getToken()
  }
  return this.http.get<any>(this.LINK_TIPOS_CURSOS + "/numero/" + id, {headers})
}
*/
  /* ========================= PROFESORES ========================= */

  async getProfesores(): Promise <any>{
    const headers = {
      //'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return  await firstValueFrom(this.http.get<any>(this.LINK_PROFESORES,  {headers} ))

  }

   async addProfesor(profesor:Profesor): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return  await firstValueFrom( this.http.post(this.LINK_PROFESORES, profesor,  {headers}))
  }

  async getProfesore(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_PROFESORES + "/" + id,  {headers} ))
  }

  async modificarProfesore(id:number, profesor:Profesor): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.put<any>(this.LINK_PROFESORES + "/" + id, profesor, {headers} ))
  }

  async borrarProfesore(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.delete<any>(this.LINK_PROFESORES + "/" + id, {headers} ))
  }

  /* ========================= BLOG ========================= */

  async getBlogs(): Promise <any>{
    const headers = {
      //'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return  await firstValueFrom(this.http.get<any>(this.LINK_BLOGS,  {headers} ))

  }

   async addBlog(blog:Blog): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return  await firstValueFrom( this.http.post(this.LINK_BLOGS, blog,  {headers}))
  }

  async getBlog(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_BLOGS + "/" + id,  {headers} ))
  }

  async modificarBlog(id:number, blog:Blog): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.put<any>(this.LINK_BLOGS + "/" + id, blog, {headers} ))
  }

  async borrarBlog(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.delete<any>(this.LINK_BLOGS + "/" + id, {headers} ))
  }


    /* ========================= CATEGORIA ========================= */

    async getCategorias(): Promise <any>{
      const headers = {
        //'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.storage.getToken()
      }
      return  await firstValueFrom(this.http.get<any>(this.LINK_CATEGORIA_BLOGS,  {headers} ))

    }

     async addCategoria(categoria:Categoria): Promise <any>{
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.storage.getToken()
      }
      return  await firstValueFrom( this.http.post(this.LINK_CATEGORIA_BLOGS, categoria,  {headers}))
    }

    async getCategoria(id:number): Promise <any>{
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.storage.getToken()
      }

      return await firstValueFrom( this.http.get<any>(this.LINK_CATEGORIA_BLOGS + "/" + id,  {headers} ))
    }

    async modificarCategoria(id:number, categoria:Categoria): Promise <any>{
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.storage.getToken()
      }

      return await firstValueFrom( this.http.put<any>(this.LINK_CATEGORIA_BLOGS + "/" + id, categoria, {headers} ))
    }

    async borrarCategoria(id:number): Promise <any>{
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.storage.getToken()
      }

      return await firstValueFrom( this.http.delete<any>(this.LINK_CATEGORIA_BLOGS + "/" + id, {headers} ))
    }
  ngOnInit(){
    console.log("From Servicio Admin: ")
  }


  /* ========================= INSCRIPCION ========================= */

  async getInscripciones(): Promise <any>{
    const headers = {
      //'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return  await firstValueFrom(this.http.get<any>(this.LINK_INSCREPCIONE,  {headers} ))

  }

  async inscribir(inscribir:Inscripcion): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }
    return await firstValueFrom( this.http.post(this.LINK_INSCREPCIONE, inscribir,  {headers}))

  }

  async getInscripcion(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.get<any>(this.LINK_INSCREPCIONE + "/" + id,  {headers} ))
  }

  async modificarInscripcion(id:number, inscripcion:Inscripcion): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.put<any>(this.LINK_INSCREPCIONE + "/" + id, inscripcion, {headers} ))
  }


  async borrarInscripcion(id:number): Promise <any>{
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.storage.getToken()
    }

    return await firstValueFrom( this.http.delete<any>(this.LINK_INSCREPCIONE + "/" + id, {headers} ))
  }



}
