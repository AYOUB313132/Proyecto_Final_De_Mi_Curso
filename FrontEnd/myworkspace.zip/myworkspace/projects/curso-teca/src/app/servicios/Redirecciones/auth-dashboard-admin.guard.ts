import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { StorageService } from '../storage.service';

export const authDashboardAdminGuard: CanActivateFn = (route, state) => {

  const storage = inject(StorageService)
  const ruta = inject(Router)

  const token = localStorage.getItem("token-curso-teca");

  if(storage.isAdminLogged()){
    return true;
  }else{
    ruta.navigateByUrl("/home")
    return false;
  }


};
