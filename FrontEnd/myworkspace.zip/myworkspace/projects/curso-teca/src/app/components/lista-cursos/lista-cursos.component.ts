import { Component, Input} from '@angular/core';
import { Curso } from '../../interfaces/curso.interface';
import { ImageURLPipe } from '../../Pipes/image-url.pipe';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AdminServicioService } from '../../servicios/servicio-admin/admin-servicio.service';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { StorageService } from '../../servicios/storage.service';
import { Usuario } from '../../interfaces/usuario.interface';



@Component({
  selector: 'app-lista-cursos',
  standalone: true,
  imports: [ImageURLPipe, RouterLink, CurrencyPipe, DatePipe],
  templateUrl: './lista-cursos.component.html',
  styleUrl: './lista-cursos.component.css'
})
export class ListaCursosComponent {
  @Input() public cursos:Curso[] = []
  @Input() public showBtnBorrar?:boolean
  usuario?:Usuario

  constructor(private auth:StorageService, private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {

  }

  async desinscribirCurso(cursoId:number){
    const usuarioId:number = Number.parseInt(   this.auth.getUsuarioId())
    if(cursoId != null && usuarioId != null){
      await this.servicio.desinscribirUsuarioDeCurso(usuarioId,cursoId).then(
        (response) =>{
          this.snackBar.open("has desinscribir este curso con exito!","Cerrar", {duration:5000})
          this.navigate.navigateByUrl("/cursos")
          return response
        }
      ).catch(
        (error) =>{
          this.snackBar.open("Error Servidor","Bad Request", {duration:5000,panelClass:"error-snackbar"})
          return error
        }

      )
    }
  }



}
