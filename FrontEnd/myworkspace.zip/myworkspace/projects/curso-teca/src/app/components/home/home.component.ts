import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CarouselComponent } from "../carousel/carousel.component";
import { SobreNosotrosComponent } from "../sobre-nosotros/sobre-nosotros.component";
import { CategoriaComponent } from "../categoria/categoria.component";
import { TestimonialComponent } from "../testimonial/testimonial.component";
import { RegistracionComponent } from "../registracion/registracion.component";
import { MatSnackBar } from '@angular/material/snack-bar';
import { Curso, Tipo } from '../../interfaces/curso.interface';
import { AdminServicioService } from '../../servicios/servicio-admin/admin-servicio.service';
import { ListaCursosComponent } from "../lista-cursos/lista-cursos.component";
import { ListaTipoCursosComponent } from "../lista-tipo-cursos/lista-tipo-cursos.component";
import { ListaProfesoresComponent } from "../lista-profesores/lista-profesores.component";
import { Profesor } from '../../interfaces/profesor.interface';
import { ListaBlogsComponent } from "../lista-blogs/lista-blogs.component";
import { Blog } from '../../interfaces/blog.interface';



@Component({
    selector: 'app-home',
    standalone: true,
    templateUrl: './home.component.html',
    styles: ``,
    imports: [RouterLink, CarouselComponent, SobreNosotrosComponent, CategoriaComponent, TestimonialComponent, RegistracionComponent, ListaCursosComponent, ListaTipoCursosComponent, ListaProfesoresComponent, ListaBlogsComponent]
})
export class HomeComponent {

  public cursos:Curso[] = []
  //public tiposCurso:Tipo[] = []
  public tiposCurso: { tipo: Tipo, numeroCursos: number }[] = [];
  public profesores: Profesor[] = []
  public blogs: Blog[] = []

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {

  }

  async ngOnInit(){
    // Cargar lista de cursos
    let allCursos = await this.servicio.getCursos().then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })
    this.cursos = allCursos.cursos.slice(0,3)

    // Cargar lista de tipo cursos:

/*
    this.tiposCurso = await this.servicio.getCursoTipos().then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })
*/
try {
      const tipos = await this.servicio.getCursoTipos();
      const tiposConNumeros = await Promise.all(tipos.map(async (tipo: Tipo) => {
        const numeroCursos = await this.servicio.getNumeroCursosDeCadaTipo(tipo.tipoId);
        return { tipo, numeroCursos };
      }));
      this.tiposCurso = tiposConNumeros;
    } catch (error) {
      console.error('Error loading data', error);
}

  // cargar lista de profesores
    const profesores = await this.servicio.getProfesores().then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })

    this.profesores = profesores.slice(0,4)

    const blogs =  await this.servicio.getBlogs().then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })

    this.blogs = blogs.slice(0,3)
  }

}
