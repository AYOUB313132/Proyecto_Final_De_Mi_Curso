import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Component } from '@angular/core';
import { AdminServicioService } from '../../../../../servicios/servicio-admin/admin-servicio.service';
import { Tipo } from '../../../../../interfaces/curso.interface';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';


@Component({
  selector: 'app-modificar-tipo-curso',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './modificar-tipo-curso.component.html',
  styleUrl: './modificar-tipo-curso.component.css'
})
export class ModificarTipoCursoComponent {


  formModificarTipo!: FormGroup;
  tipo!: Tipo;

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {}

  ngOnInit() {
    this.ruta.params.subscribe(async params => {
      const tipoId = params['id'];
      this.tipo = await this.servicio.getCursoTipo(tipoId).then((res) => {
        return  res;
      }).catch( (error) =>{
          return error;
      });

      this.initializeForm();
    });
  }

  initializeForm() {
    this.formModificarTipo = new FormGroup({
      'tipoNombre': new FormControl((this.tipo ? this.tipo.tipoNombre : ''), Validators.required),
      'imagen': new FormControl((this.tipo ? this.tipo.imagen : '')),

    });
  }

  async ModificarTipo(){
    await this.servicio.modificarTipoCurso(this.tipo.tipoId, this.formModificarTipo.value)
      .then((res) => {
        this.snackBar.open("Ha modificado el Tipo con exito!!", "Cerrar", {duration:5000});
        this.navigate.navigateByUrl("/admin-dashboard");
        return res;
      }).catch( (error) => {
        this.snackBar.open("Error Servidor","Bad Request" + error, {duration:5000,panelClass:"error-snackbar"})
      })

  }
}
