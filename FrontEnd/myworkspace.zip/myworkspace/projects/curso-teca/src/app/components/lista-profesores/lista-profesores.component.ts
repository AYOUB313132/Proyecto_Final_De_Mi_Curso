import { Component, Input } from '@angular/core';
import { Profesor } from '../../interfaces/profesor.interface';
import { AdminServicioService } from '../../servicios/servicio-admin/admin-servicio.service';
import { RouterLink } from '@angular/router';
import { ImageURLPipe } from '../../Pipes/image-url.pipe';

@Component({
  selector: 'app-lista-profesores',
  standalone: true,
  imports: [ImageURLPipe,RouterLink],
  templateUrl: './lista-profesores.component.html',
  styleUrl: './lista-profesores.component.css'
})
export class ListaProfesoresComponent {

  @Input() profesores: Profesor[] = []
  constructor(private servicioAdmin: AdminServicioService){}




}
