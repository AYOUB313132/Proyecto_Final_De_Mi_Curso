import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { Profesor } from '../../../../interfaces/profesor.interface';

@Component({
  selector: 'app-modificar-profesor',
  standalone: true,
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: './modificar-profesor.component.html',
  styleUrl: './modificar-profesor.component.css'
})
export class ModificarProfesorComponent {

  formModificarProfesor!: FormGroup;
  profesor!: Profesor;

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {}

  ngOnInit() {
    this.ruta.params.subscribe(async params => {
      const profesorId = params['id'];
      this.profesor = await this.servicio.getProfesore(profesorId).then((res) => {
        return  res;
      }).catch( (error) =>{
          return error;
      });

      this.initializeForm();
    });
  }

  initializeForm() {
    this.formModificarProfesor = new FormGroup({
      'nombre': new FormControl((this.profesor ? this.profesor.nombre : ''), Validators.required),
      'apellido': new FormControl((this.profesor ? this.profesor.apellido : ''), Validators.required),
      'especialidad': new FormControl((this.profesor ? this.profesor.especialidad : ''), Validators.required),
      'imagen': new FormControl((this.profesor ? this.profesor.imagen : '')),
      'linkTwitter': new FormControl((this.profesor ? this.profesor.linkTwitter : '')),
      'linkLinkedin': new FormControl((this.profesor ? this.profesor.linkLinkedin : '')),
    });
  }

  async modificarProfesor(){
    await this.servicio.modificarProfesore(this.profesor.id, this.formModificarProfesor.value)
      .then((res) => {
        this.snackBar.open("Ha modificado el Profesor con exito!!", "Cerrar", {duration:5000});
        this.navigate.navigateByUrl("/admin-dashboard");
        return res;
      }).catch( (error) => {
        this.snackBar.open("Error Servidor","Bad Request" + error, {duration:5000,panelClass:"error-snackbar"})
      })

  }

}
