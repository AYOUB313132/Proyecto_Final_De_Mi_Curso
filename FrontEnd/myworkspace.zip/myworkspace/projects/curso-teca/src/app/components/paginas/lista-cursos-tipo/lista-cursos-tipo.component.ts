import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Curso, Tipo } from '../../../interfaces/curso.interface';
import { AdminServicioService } from '../../../servicios/servicio-admin/admin-servicio.service';
import { ImageURLPipe } from '../../../Pipes/image-url.pipe';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { ListaCursosComponent } from "../../lista-cursos/lista-cursos.component";

@Component({
    selector: 'app-lista-cursos-tipo',
    standalone: true,
    templateUrl: './lista-cursos-tipo.component.html',
    styleUrl: './lista-cursos-tipo.component.css',
    imports: [ImageURLPipe, RouterLink, CurrencyPipe, DatePipe, ListaCursosComponent]
})
export class ListaCursosTipoComponent {

  NombrePagina:string = "Cursos de tipo";
  public cursos:Curso[] = []
  public tipo?:Tipo;


  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {

  }


  async ngOnInit(){
    this.ruta.params.subscribe(async params => {
      const tipoId = params['id'];
      this.cursos = await this.servicio.getCursosDeTipo(tipoId).then( (response) =>{
        return response;
      }).catch( (error) =>{
        return error;
      })

      this.tipo = await this.servicio.getCursoTipo(tipoId).then( (response) =>{
        return response;
      }).catch( (error) =>{
        return error;
      })

    })
  }







}
