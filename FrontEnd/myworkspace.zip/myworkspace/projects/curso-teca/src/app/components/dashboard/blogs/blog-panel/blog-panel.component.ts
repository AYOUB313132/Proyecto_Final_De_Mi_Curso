import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Blog } from '../../../../interfaces/blog.interface';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faTrashCan} from '@fortawesome/free-regular-svg-icons';
import { faPencil } from '@fortawesome/free-solid-svg-icons';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-blog-panel',
  standalone: true,
  imports: [RouterLink, FontAwesomeModule, DatePipe],
  templateUrl: './blog-panel.component.html',
  styleUrl: './blog-panel.component.css'
})
export class BlogPanelComponent {

  iconoBorrar = faTrashCan
  iconoModificar = faPencil
  iconoAnadir = faPlus

  public blogs:Blog [] = []

  constructor(private servicio:AdminServicioService, private ruta:Router,
     private snackBar: MatSnackBar,private dialog: MatDialog){
  }

  async ngOnInit(){
      this.blogs = await this.servicio.getBlogs()
  }

  async BorrarBlog(event:any,id: number) {

    if(confirm("Quieres borrar este blog")){
      event.target.innerText = "Borrar..."
      await this.servicio.borrarBlog(id).then((r) =>{
        this.snackBar.open("Ha borrado el blog con exito!!", "Cerrar", {duration:5000});
        window.location.reload()
        return r;
      }).catch((error) =>{
        this.snackBar.open("Fallo en servicor" + error, "Cerrar", {duration:5000});
      })

    }
  }
}
