import { RouterLink } from '@angular/router';
import { Component, EventEmitter, Output, output } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faClose } from '@fortawesome/free-solid-svg-icons';
import { faHome } from '@fortawesome/free-solid-svg-icons';
import { navbarData } from './nav-data';

@Component({
  selector: 'app-sidbar',
  standalone: true,
  imports: [FontAwesomeModule, RouterLink],
  templateUrl: './sidbar.component.html',
  styleUrl: './sidbar.component.css'
})
export class SidbarComponent {

  faClose = faClose;
  faHome = faHome;

  collapsed:boolean = false
  navData =navbarData;

  @Output() onToggleSideBar = new EventEmitter();

  toggleSidBar() {
    this.collapsed = ! this.collapsed
  }

  @Output() showBody = new EventEmitter();

  usuarios:boolean = false
  profesores:boolean = false
  cursos:boolean = false

  showUsuariosPanel(){
    this.profesores = false
    this.cursos = false
    this.showBody.emit(!this.usuarios)
  }

  showProfesoresPanel(){
    this.usuarios = false
    this.cursos = false
    this.showBody.emit(!this.profesores)
  }

  showCursosPanel(){
    this.profesores = false
    this.usuarios = false
    this.showBody.emit(!this.cursos)
  }

}
