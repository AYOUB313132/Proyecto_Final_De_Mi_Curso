import { Component } from '@angular/core';
import { Tipo } from '../../../../../interfaces/curso.interface';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';
import { AdminServicioService } from '../../../../../servicios/servicio-admin/admin-servicio.service';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faTrashCan} from '@fortawesome/free-regular-svg-icons';
import { faPencil } from '@fortawesome/free-solid-svg-icons';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'app-tipo-curso-panel',
  standalone: true,
  imports: [RouterLink, FontAwesomeModule],
  templateUrl: './tipo-curso-panel.component.html',
  styleUrl: './tipo-curso-panel.component.css'
})
export class TipoCursoPanelComponent {

  iconoBorrar = faTrashCan
  iconoModificar = faPencil
  iconoAnadir = faPlus

  public tipos:Tipo [] = []

  constructor(private servicio:AdminServicioService, private ruta:Router,
     private snackBar: MatSnackBar,private dialog: MatDialog){
  }

  async ngOnInit(){
      this.tipos = await this.servicio.getCursoTipos();
  }

  async BorrarTipo(event:any,id: number) {

    if(confirm("Quieres borrar este Tipo de cursos")){
      event.target.innerText = "Borrar..."
      await this.servicio.borrarTipoCurso(id).then((r) =>{
        this.snackBar.open("Ha borrado el Tipo con exito!!", "Cerrar", {duration:5000});
        window.location.reload()
        return r;
      }).catch((error) =>{
        this.snackBar.open("Fallo en servicor" + error, "Cerrar", {duration:5000});
      })

    }
  }



}
