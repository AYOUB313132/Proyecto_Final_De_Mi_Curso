import { Component } from '@angular/core';
import { Usuario } from '../../../../interfaces/usuario.interface';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-modif-usuario',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './modif-usuario.component.html',
  styleUrl: './modif-usuario.component.css'
})
export class ModifUsuarioComponent {


  nombreImagen = '';
  img!: File

  formModificarUsuario!: FormGroup;
  public roles:string [] = []
  public usuario!: Usuario
  id!:number


  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {
    this.formModificarUsuario = new FormGroup ({
      'role': new FormControl((this.usuario ? this.usuario.role : ''), Validators.required),
    })
  }

  async ngOnInit() {

    // Cargar la lista de roles
    this.roles = ["ADMIN", "PROFESOR", "USER"]


    this.ruta.params.subscribe(async params => {
      const usuarioId = params['id'];
      this.id = usuarioId
      this.usuario = await this.servicio.getUsuario(usuarioId).then((res) => {
        return  res;
      }).catch( (error) =>{
          return error;
      });


    });
  }



  async modificarUsuario(){
    if(this.formModificarUsuario.valid){
       const us:Usuario = {
        id: this.usuario.id,
        nombre: this.usuario.nombre,
        apellido: this.usuario.apellido,
        email: this.usuario.email,
        movil: this.usuario.movil,
        // a qui pasamos el nuevo role del usuario
        role: this.formModificarUsuario.getRawValue().role,
        imagen: this.usuario.imagen,
        fechaNacimiento : this.usuario.fechaNacimiento,
        genero : this.usuario.genero,
        direccion :this.usuario.direccion,
        codigoPostal : this.usuario.codigoPostal,
        ciudad : this.usuario.ciudad,
        provincia : this.usuario.provincia,
        pais : this.usuario.pais
    };
    console.log(this.id,us);
      await this.servicio.setRoleUsuario(this.usuario.id,us).then( (res) => {
          this.snackBar.open("Ha modificado el role de usuario con exito!!" + res.message, "Cerrar", {duration:5000});
          this.navigate.navigateByUrl("/admin-dashboard");
        }).catch( (error) => {
          this.snackBar.open("Error Servidor","Bad Request" + error.error, {duration:5000,panelClass:"error-snackbar"})
        })
  }
}



}
