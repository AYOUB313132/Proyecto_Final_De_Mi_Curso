import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';
import { FileUploadServiceService } from '../../../../servicios/file-upload-service.service';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { Blog, Categoria } from '../../../../interfaces/blog.interface';

@Component({
  selector: 'app-add-blog',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './add-blog.component.html',
  styleUrl: './add-blog.component.css'
})
export class AddBlogComponent {




  public formAddBlog: FormGroup;
  public blog!: Blog
  public categorias: Categoria[] = []
  public categoria!: Categoria
  public categoriaID!: number

  nombreImagen = '';
  img!: File

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: Router) {

    this.formAddBlog = new FormGroup({
      'titulo': new FormControl('', Validators.required),
      'fecha': new FormControl(new Date().toISOString().substring(0, 10), Validators.required),
      'parrafo': new FormControl('', Validators.required),
      'categoria': new FormControl('', Validators.required),
      'descripcion': new FormControl('', Validators.required),
      'imagen': new FormControl(''),
    })

  }


  async addBlog() {

    if (this.formAddBlog.valid) {

      this.categoria = await this.servicio.getCategoria(this.formAddBlog.getRawValue().categoria)

      console.log("this categoria: " + this.categoria)

      const blogConCategoria: Blog = {
        id: 0,
        titulo: this.formAddBlog.getRawValue().titulo,
        parrafo: this.formAddBlog.getRawValue().parrafo,
        descripcion: this.formAddBlog.getRawValue().descripcion,
        fecha: this.formAddBlog.getRawValue().fecha,
        categoria: this.categoria,
        imagen: (this.img) ? this.img.name : ' ',
      };


      // Añadir imagen
      if (this.img) {
        this.nombreImagen = this.img.name
        this.servicio.añadirImagen(this.img).subscribe((res) => {
        })
      }
      await this.servicio.addBlog(blogConCategoria).then(
        (response) => {
          this.snackBar.open("El Blog ha añadido con exito!", "Cerrar", { duration: 5000 })
          this.ruta.navigateByUrl("/blog")
          return response
        }
      ).catch(
        (error) => {
          this.snackBar.open("Error Servidor", "Bad Request", { duration: 5000, panelClass: "error-snackbar" })
          return error
        }

      )


    } else {
      console.log("Not valid")
    }

  }

  async ngOnInit(): Promise<void> {
    // Cargar la lista de categorias
    this.categorias = await this.servicio.getCategorias();

  }

  async onSelectImg(event: any) {
    this.img = event.target.files[0]
    this.formAddBlog.patchValue({
      imagen: this.img.name
    });
  }
}
