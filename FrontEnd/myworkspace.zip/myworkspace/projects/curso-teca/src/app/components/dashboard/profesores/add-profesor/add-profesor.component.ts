import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { FileUploadServiceService } from '../../../../servicios/file-upload-service.service';
import { HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-add-profesor',
  standalone: true,
  imports: [RouterLink,ReactiveFormsModule],
  templateUrl: './add-profesor.component.html',
  styleUrl: './add-profesor.component.css'
})
export class AddProfesorComponent {

  formAddProfesor: FormGroup;


  nombreImagen = '';
  img!:File


  constructor(private servicio:AdminServicioService, private snackBar:MatSnackBar,
    private ruta:Router, private uploadService: FileUploadServiceService){
    this.formAddProfesor = new FormGroup({
      'nombre' : new FormControl('', Validators.required),
      'apellido' : new FormControl('', Validators.required),
      'especialidad' : new FormControl('', Validators.required),
      'imagen' : new FormControl(''),
      'linkTwitter' : new FormControl(''),
      'linkLinkedin' : new FormControl(''),
    })
  }
  ngOnInit(): void {
  }


  async addProfesor(){
    if(this.formAddProfesor.valid){
      // Añadir imagen
      if(this.img){
        this.nombreImagen = this.img.name
        this.servicio.añadirImagen(this.img).subscribe( (res) =>{
      })
      }

      //Añadir profesor
      await this.servicio.addProfesor(
        this.formAddProfesor.value).then( (res) =>{

          this.snackBar.open("El profesor ha añadido con exito!" ,"Cerra", {duration:5000})
          this.ruta.navigateByUrl("/profesores")
          return res;
        }).catch( (error) => {
          if(error.status === 409){
            this.snackBar.open(error.error,"Error", {duration:5000,panelClass:"error-snackbar"})
          }else{
            this.snackBar.open("Error Servidor" + error,"Bad Request", {duration:5000,panelClass:"error-snackbar"})
          }
        })

    }
  }


  async onSelectImg(event:any){
    this.img = event.target.files[0]
    this.formAddProfesor.patchValue({
      imagen: this.img.name
    });
  }



}
