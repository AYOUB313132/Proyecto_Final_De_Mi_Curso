export const navbarData = [
  {
    routLink: "dashboard",
    icon : "fal, fa-home",
    label : "Dashboard"
  }
]
