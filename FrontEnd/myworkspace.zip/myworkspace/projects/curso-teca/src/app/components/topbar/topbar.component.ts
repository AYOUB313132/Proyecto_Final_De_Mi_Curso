import { Router, RouterLink } from '@angular/router';
import { StorageService } from './../../servicios/storage.service';
import { Component } from '@angular/core';
import { Usuario } from '../../interfaces/usuario.interface';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './topbar.component.html',
  styles: ``
})
export class TopbarComponent {

  constructor(private storage:StorageService, private ruta:Router){}

  token?:string
  usuario!:Usuario

  isUsuarioLoggedIn: boolean = this.storage.isUsuarioLogged();
  isAdminLoggedIn: boolean = this.storage.isAdminLogged();
  isProfesorLoggedIn: boolean = this.storage.isProfesorLogged();

  ngOnInit(){
    this.ruta.events.subscribe(ev =>{
      this.token = this.storage.getToken();
      this.usuario = this.storage.getUsuario();
      this.isUsuarioLoggedIn = this.storage.isUsuarioLogged();
      this.isAdminLoggedIn = this.storage.isAdminLogged();
      this.isProfesorLoggedIn = this.storage.isProfesorLogged();
    })
  }
}
