import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-registracion',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './registracion.component.html',
  styles: ``
})
export class RegistracionComponent {

}
