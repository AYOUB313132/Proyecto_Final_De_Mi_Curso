import { ImageURLPipe } from './../../Pipes/image-url.pipe';
import { DatePipe } from '@angular/common';
import { Component, Input } from '@angular/core';
import { Blog } from '../../interfaces/blog.interface';

@Component({
  selector: 'app-lista-blogs',
  standalone: true,
  imports: [DatePipe, ImageURLPipe],
  templateUrl: './lista-blogs.component.html',
  styleUrl: './lista-blogs.component.css'
})
export class ListaBlogsComponent {

  @Input() public blogs: Blog[] = []






}
