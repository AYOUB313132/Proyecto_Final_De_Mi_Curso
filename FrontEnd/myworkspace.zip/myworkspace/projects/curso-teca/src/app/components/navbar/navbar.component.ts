import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { StorageService } from '../../servicios/storage.service';
import { Usuario } from '../../interfaces/usuario.interface';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './navbar.component.html',
  styles: ``
})
export class NavbarComponent {

  constructor(private storage:StorageService, private ruta:Router){}

  usuario?:Usuario
  token?:string

  isLoggedIn: boolean = false;

  isUsuarioLoggedIn: boolean = this.storage.isUsuarioLogged();
  isAdminLoggedIn: boolean = this.storage.isAdminLogged();
  isProfesorLoggedIn: boolean = this.storage.isProfesorLogged();


  ngOnInit(){
    this.ruta.events.subscribe(ev =>{
      this.token = this.storage.getToken();
      this.usuario = this.storage.getUsuario();
      this.isUsuarioLoggedIn = this.storage.isUsuarioLogged();
      this.isAdminLoggedIn = this.storage.isAdminLogged();
      this.isProfesorLoggedIn = this.storage.isProfesorLogged();
    })
  }

  logout() {
    this.storage.logout();
    this.ruta.navigate(['/login'])
    }

}
