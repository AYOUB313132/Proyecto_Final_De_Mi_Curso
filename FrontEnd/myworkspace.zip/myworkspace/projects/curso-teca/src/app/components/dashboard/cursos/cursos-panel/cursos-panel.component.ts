import { Curso } from '../../../../interfaces/curso.interface';
import { Component } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faTrashCan} from '@fortawesome/free-regular-svg-icons';
import { faPencil } from '@fortawesome/free-solid-svg-icons';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'app-cursos-panel',
  standalone: true,
  imports: [DatePipe, RouterLink, FontAwesomeModule],
  templateUrl: './cursos-panel.component.html',
  styleUrl: './cursos-panel.component.css'
})
export class CursosPanelComponent {

  iconoBorrar = faTrashCan
  iconoModificar = faPencil
  iconoAnadir = faPlus
  
  public cursos:Curso [] = []

  constructor(private servicio:AdminServicioService,
    private snackBar: MatSnackBar){
  }

  async ngOnInit(){
      let f = await this.servicio.getCursos()
      this.cursos = f.cursos

  }

  async BorrarCurso(event:any,id: number) {
    if(confirm("Quieres borrar este Curso")){
      event.target.innerText = "Borrar..."
      await this.servicio.borrarCurso(id).then( (response) =>{
        this.snackBar.open("Ha borrado el Curso con exito!!", "Cerrar", {duration:3000});
        window.location.reload()
        return response
      }).catch( (error) =>{
        return error
      })

    }else{
      console.log("No")
    }
  }

}
