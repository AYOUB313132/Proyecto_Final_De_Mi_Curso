import { Component } from '@angular/core';

@Component({
  selector: 'app-sobre-nosotros',
  standalone: true,
  imports: [],
  templateUrl: './sobre-nosotros.component.html',
  styles: ``
})
export class SobreNosotrosComponent {

}
