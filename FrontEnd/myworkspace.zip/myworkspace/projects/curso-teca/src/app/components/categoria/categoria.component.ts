import { Component } from '@angular/core';

@Component({
  selector: 'app-categoria',
  standalone: true,
  imports: [],
  templateUrl: './categoria.component.html',
  styles: ``
})
export class CategoriaComponent {

}
