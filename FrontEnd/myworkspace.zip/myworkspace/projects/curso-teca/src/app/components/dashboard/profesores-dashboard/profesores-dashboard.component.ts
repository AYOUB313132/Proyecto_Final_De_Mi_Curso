import { Component } from '@angular/core';

@Component({
    selector: 'app-profesores-dashboard',
    standalone: true,
    templateUrl: './profesores-dashboard.component.html',
    styles: ``,
    imports: []
})
export class ProfesoresDashboardComponent {


}
