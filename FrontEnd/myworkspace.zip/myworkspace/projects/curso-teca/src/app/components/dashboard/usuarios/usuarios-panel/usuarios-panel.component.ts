import { Usuario } from '../../../../interfaces/usuario.interface';
import { Component } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { RouterLink } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faTrashCan} from '@fortawesome/free-regular-svg-icons';
import { faPencil } from '@fortawesome/free-solid-svg-icons';
import { faPlus } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-usuarios-panel',
  standalone: true,
  imports: [DatePipe, RouterLink, FontAwesomeModule],
  templateUrl: './usuarios-panel.component.html',
  styleUrl: './usuarios-panel.component.css'
})
export class UsuariosPanelComponent {

  iconoBorrar = faTrashCan
  iconoModificar = faPencil
  iconoAnadir = faPlus

  public usuarios:Usuario [] = []

  constructor(private servicio:AdminServicioService,
    private snackBar: MatSnackBar){
  }

  async ngOnInit(){
    this.usuarios = await this.servicio.getUsuarios().then( (r) => {
      return r;
    }).catch( (error) => {
      return error
    })
  }

  async BorrarUsuario(event:any,id: number) {

    console.log(id)

    if(confirm("Quieres borrar este Usuario")){
      event.target.innerText = "Borrar..."
      await this.servicio.borrarUsuario(id).then((r) =>{
        this.snackBar.open("Ha borrado el Usuario con exito!!", "Cerrar", {duration:5000});
        window.location.reload()
      }).catch( (error) =>{
        this.snackBar.open("Fallo en servicor" + error, "Cerrar", {duration:5000});
      })
    }
  }


}
