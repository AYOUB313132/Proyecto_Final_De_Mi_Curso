import { Component } from '@angular/core';
import { ListaCursosComponent } from "../../lista-cursos/lista-cursos.component";
import { Curso } from '../../../interfaces/curso.interface';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminServicioService } from '../../../servicios/servicio-admin/admin-servicio.service';
import { Usuario } from '../../../interfaces/usuario.interface';

@Component({
    selector: 'app-lista-mi-cursos',
    standalone: true,
    templateUrl: './lista-mi-cursos.component.html',
    styleUrl: './lista-mi-cursos.component.css',
    imports: [ListaCursosComponent]
})
export class ListaMiCursosComponent {

  public cursos:Curso[] = []
  public usuario?:Usuario

  showBtnBorrar:boolean = true

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {

  }

  async ngOnInit(){
    this.ruta.params.subscribe(async params => {
      const usuarioId = params['id'];

    this.cursos = await this.servicio.getCursosUsuario(usuarioId).then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })

  })
  }

}
