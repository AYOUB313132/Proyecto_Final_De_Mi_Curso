import { Observable } from 'rxjs';
import { Component, Input, SimpleChanges } from '@angular/core';
import { ImageURLPipe } from '../../Pipes/image-url.pipe';
import { Tipo } from '../../interfaces/curso.interface';
import { AdminServicioService } from '../../servicios/servicio-admin/admin-servicio.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-lista-tipo-cursos',
  standalone: true,
  imports: [ImageURLPipe, RouterLink],
  templateUrl: './lista-tipo-cursos.component.html',
  styleUrl: './lista-tipo-cursos.component.css'
})
export class ListaTipoCursosComponent {

  //@Input() tiposCurso:Tipo[] = []
  @Input() tiposCurso?: { tipo: Tipo, numeroCursos: number }[] = [];
  //numerosCursos: Map<number, number> = new Map();

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {

  }

  ngOnInit(): void {


  }



trackByTipoId(index: number, tipo: { tipo: Tipo, numeroCursos: number }): number {
  return tipo.tipo.tipoId;
}


}
