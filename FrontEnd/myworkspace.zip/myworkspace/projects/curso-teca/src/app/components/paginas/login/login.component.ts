import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { HeaderComunesPaginasComponent } from "../header-comunes-paginas/header-comunes-paginas.component";
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthServiceService } from '../../../servicios/auth-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { StorageService } from '../../../servicios/storage.service';

@Component({
    selector: 'app-login',
    standalone: true,
    templateUrl: './login.component.html',
    styles: ``,
    imports: [RouterLink, HeaderComunesPaginasComponent, ReactiveFormsModule]
})
export class LoginComponent {

  formLogin: FormGroup;

  constructor (private snackbar:MatSnackBar, private authService: AuthServiceService, private ruta:Router, private storage: StorageService){
    this.formLogin = new FormGroup({
      'email' : new FormControl('', [Validators.required, Validators.email]),
      'contraseña' : new FormControl('', [Validators.required])
    })
  }


  login (){
    if(this.formLogin.valid){
      console.log("Valid")
      console.log(this.formLogin.value)
      this.authService.login(this.formLogin.value).subscribe((res) => {
        console.log(res)
        if(res.statusCode == 200){
          this.snackbar.open(res.message, "Close", {duration:5000})
          const user = res.usuario;
          this.storage.saveUser(user);
          this.storage.saveToken(res.token);
          if(this.storage.isAdminLogged()){
            this.ruta.navigateByUrl("/admin-dashboard");
          }else if(this.storage.isProfesorLogged()) {
            this.ruta.navigateByUrl("/cursos")
          }else{
            this.ruta.navigateByUrl("/home")
          }

        }else{
          this.snackbar.open("Login faild, Try again", "Close", {duration:5000,panelClass:"error-snackbar"});
        }
      })
    }else{
      console.log("Not Valid")
    }
  }



}
