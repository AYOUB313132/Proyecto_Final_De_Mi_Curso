import { AuthServiceService } from './../../servicios/auth-service.service';
import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HeaderComunesPaginasComponent } from "../paginas/header-comunes-paginas/header-comunes-paginas.component";
import { Curso } from '../../interfaces/curso.interface';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AdminServicioService } from '../../servicios/servicio-admin/admin-servicio.service';
import { ImageURLPipe } from '../../Pipes/image-url.pipe';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { Profesor } from '../../interfaces/profesor.interface';
import { Usuario } from '../../interfaces/usuario.interface';
import { StorageService } from '../../servicios/storage.service';
import { Inscripcion } from '../../interfaces/inscrepcion.interface';

@Component({
    selector: 'app-curso-detalles',
    standalone: true,
    templateUrl: './curso-detalles.component.html',
    styleUrl: './curso-detalles.component.css',
    imports: [RouterLink, HeaderComunesPaginasComponent,  ImageURLPipe, DatePipe, CurrencyPipe]
})
export class CursoDetallesComponent {

  NombrePagina:string = "Curso Detalles";
  public curso!:Curso
  public profesor!:Profesor
  public usuario!: Usuario
   inscribir!:Inscripcion

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar,
     private ruta: ActivatedRoute, private navigate:Router, private storage:StorageService) {

  }

  async ngOnInit() {

    // Cargar el Curso Detalles

    this.ruta.params.subscribe(async params => {
      const curspoId = params['id'];

      this.curso = await this.servicio.getCurso(curspoId).then((res) => {
        return  res;
      }).catch( (error) =>{
          return error;
      });

       // Cargar el profesor del curso
    this.profesor = await this.servicio.getProfesore(this.curso.profesorId);
    this.usuario = this.storage.getUsuario();
      console.log("Usuario: " + this.usuario.nombre)
    })

    // get Usuario

    this.usuario = this.storage.getUsuario();

  }

   async inscribirInCurso(event:any){
    const ins: Inscripcion = {
      id : 0,
      cursoId : this.curso.cursoId,
      usuarioId: this.usuario.id
    }
    if(ins != null){
      await this.servicio.inscribir(ins).then(
          (response) =>{
            this.snackBar.open("has inscrito en el curso con exito!","Cerrar", {duration:5000})
            this.navigate.navigateByUrl("/cursos")
            return response
          }
        ).catch(
          (error) =>{
            if(error.status === 409){
              this.snackBar.open(error.error,"Error", {duration:5000,panelClass:"error-snackbar"})
            }else{
              this.snackBar.open("Error Servidor" + error,"Bad Request", {duration:5000,panelClass:"error-snackbar"})
            }
        })
    }





}

}
