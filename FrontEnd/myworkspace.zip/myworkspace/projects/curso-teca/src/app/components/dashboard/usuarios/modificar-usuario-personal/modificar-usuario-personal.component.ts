import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Usuario } from '../../../../interfaces/usuario.interface';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { ImageURLPipe } from '../../../../Pipes/image-url.pipe';

@Component({
  selector: 'app-modificar-usuario-personal',
  standalone: true,
  imports: [RouterLink, ReactiveFormsModule, ImageURLPipe],
  templateUrl: './modificar-usuario-personal.component.html',
  styleUrl: './modificar-usuario-personal.component.css'
})
export class ModificarUsuarioPersonalComponent {



  nombreImagen = '';
  img!: File

  formModificarDatos!: FormGroup;
  public usuario!: Usuario
  id!:number


  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {

  }

  async ngOnInit() {

    this.ruta.params.subscribe(async params => {
      const usuarioId = params['id'];
      this.id = usuarioId
      this.usuario = await this.servicio.getUsuario(usuarioId).then((res) => {
        return  res;
      }).catch( (error) =>{
          return error;
      });
      console.log("Usuario: " + JSON.stringify(this.usuario))
      this.initForm();
    });


  }

  initForm(): void {
    this.formModificarDatos = new FormGroup({
      'nombre': new FormControl((this.usuario ? this.usuario.nombre : ''), Validators.required),
      'apellido': new FormControl((this.usuario ? this.usuario.apellido : ''), Validators.required),
      'genero': new FormControl((this.usuario? this.usuario.genero : ''), Validators.required),
      'fechaNacimiento': new FormControl((this.usuario ? new Date(this.usuario.fechaNacimiento).toISOString().substring(0,10) : ''), Validators.required),
      'email': new FormControl((this.usuario? this.usuario.email : ''), Validators.required),
      'movil': new FormControl((this.usuario? this.usuario.movil : ''), Validators.required),
      'contraseña': new FormControl('', Validators.required),
      'confirmContraseña' : new FormControl('', Validators.required),
      'imagen': new FormControl(''),
    });
  }

  async modificarUsuario(){

    if(this.formModificarDatos.valid){
      console.log("Value Form: " + JSON.stringify(this.formModificarDatos.value))
       const us:Usuario = {
        id: this.formModificarDatos.getRawValue().id,
        nombre: this.formModificarDatos.getRawValue().nombre,
        apellido: this.formModificarDatos.getRawValue().apellido,
        email: this.formModificarDatos.getRawValue().email,
        movil: this.formModificarDatos.getRawValue().movil,
        role: this.usuario.role,
        imagen: this.formModificarDatos.getRawValue().imagen,
        fechaNacimiento : this.formModificarDatos.getRawValue().fechaNacimiento,
        genero : this.formModificarDatos.getRawValue().genero,
        direccion :this.formModificarDatos.getRawValue().direccion,
        codigoPostal : this.formModificarDatos.getRawValue().codigoPostal,
        ciudad : this.formModificarDatos.getRawValue().ciudad,
        provincia : this.formModificarDatos.getRawValue().provincia,
        pais : this.formModificarDatos.getRawValue().pais
    };
    const contraseña = this.formModificarDatos.get("contraseña")?.value;
    const confirmContraseña = this.formModificarDatos.get("confirmContraseña")?.value;

    if(contraseña !== confirmContraseña){
      this.snackBar.open("Contraseña not igual", "Close", {duration:5000,panelClass:"error-snackbar"});
      return;
    }

     // Añadir imagen
     if(this.img){
      this.nombreImagen = this.img.name
      this.servicio.añadirImagen(this.img).subscribe( (res) =>{
        return res;
    })
    }

    await this.servicio.modificarUsuario(us.id,this.formModificarDatos.value).then((res) => {
      console.log(res);

        this.snackBar.open(res.message, "Close", {duration:5000});
        this.navigate.navigateByUrl("/home");
      }).catch( (error) =>{
        this.snackBar.open("Registacion faild, Try again" + error.error, "Close", {duration:5000,panelClass:"error-snackbar"});
      })


  }else{
    console.log("not valid")
  }
}

onSelectImg(event:any){
  this.img = event.target.files[0]
  console.log(this.img.name)
  this.formModificarDatos.patchValue({
    imagen: this.img.name
  });
}


}
