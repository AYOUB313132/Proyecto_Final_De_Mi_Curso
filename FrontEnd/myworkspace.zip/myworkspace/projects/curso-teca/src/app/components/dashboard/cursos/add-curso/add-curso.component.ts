import { Curso, Tipo } from './../../../../interfaces/curso.interface';
import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { Profesor } from '../../../../interfaces/profesor.interface';



@Component({
  selector: 'app-add-curso',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './add-curso.component.html',
  styleUrl: './add-curso.component.css'
})
export class AddCursoComponent {



  public formAddCurso: FormGroup;
  public curso!: Curso
  public tipoCurso!:Tipo
  public TiposDeCurso:Tipo [] = []
  public profesores:Profesor[] = []
  public profesor!:Profesor
  public profesorID!:number

  nombreImagen = '';
  img!:File

  constructor(private servicio:AdminServicioService, private snackBar:MatSnackBar, private ruta:Router){

    this.formAddCurso = new FormGroup({
      'nombreCurso' : new FormControl('', Validators.required),
      'detallesDelCurso' : new FormControl('', Validators.required),
      'fechaInicio' : new FormControl(new Date().toISOString().substring(0,10), Validators.required),
      'fechaFinal' : new FormControl(new Date().toISOString().substring(0,10), Validators.required),
      'profesor' : new FormControl(''),
      'precio' : new FormControl(''),
      'tipo' : new FormControl(''),
      'imagen' : new FormControl(''),
    })

  }


  async addCurso(){

    const diaHoy = new Date().getTime()

    if(this.formAddCurso.valid){

      this.profesor = await this.servicio.getProfesore(this.formAddCurso.getRawValue().profesor)

      this.tipoCurso = await this.servicio.getCursoTipo(this.formAddCurso.getRawValue().tipo)

      const cursoConTipo: Curso = {
        cursoId: 0,
        nombreCurso: this.formAddCurso.getRawValue().nombreCurso,
        detallesDelCurso: this.formAddCurso.getRawValue().detallesDelCurso,
        fechaInicio: this.formAddCurso.getRawValue().fechaInicio,
        fechaFinal: this.formAddCurso.getRawValue().fechaFinal,
        profesorId: this.profesor.id,
        tipo: this.tipoCurso,
        precio : this.formAddCurso.getRawValue().precio,
        imagen: (this.img)? this.img.name:'',
    };

       const fInicio = new Date (this.formAddCurso.getRawValue().fechaInicio ).getTime()
       const fFinal = new Date (this.formAddCurso.getRawValue().fechaFinal ).getTime()

      if(fFinal > fInicio && fInicio > diaHoy){
        // Añadir imagen
      if(this.img){
        this.nombreImagen = this.img.name
        this.servicio.añadirImagen(this.img).subscribe( (res) =>{
      })
      }
        await this.servicio.addCurso(cursoConTipo).then(
          (response) =>{
            this.snackBar.open("El Curso ha añadido con exito!","Cerrar", {duration:5000})
            this.ruta.navigateByUrl("/cursos")
            return response
          }
        ).catch(
          (error) =>{
            this.snackBar.open("Error Servidor","Bad Request", {duration:5000,panelClass:"error-snackbar"})
            return error
          }

        )
      }else{
        alert("La fecha Inicio debe ser antes fecha final")
      }

    }else{
      console.log("Not valid")
    }
    console.log("this.tipoCurso: " + this.tipoCurso)
  }

  async ngOnInit(): Promise<void>{
    // Cargar la lista de TiposCurso
     this.TiposDeCurso= await this.servicio.getCursoTipos();

    // Cargar la lista de Profesores
      this.profesores = await this.servicio.getProfesores()

  }

  async onSelectImg(event: any) {
    this.img = event.target.files[0]
        this.formAddCurso.patchValue({
          imagen: this.img.name
        });
    }


}
