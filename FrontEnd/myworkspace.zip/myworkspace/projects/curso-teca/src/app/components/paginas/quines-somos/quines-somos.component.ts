import { Component } from '@angular/core';
import { HeaderComunesPaginasComponent } from "../header-comunes-paginas/header-comunes-paginas.component";

@Component({
    selector: 'app-quines-somos',
    standalone: true,
    templateUrl: './quines-somos.component.html',
    styles: ``,
    imports: [HeaderComunesPaginasComponent]
})
export class QuinesSomosComponent {

  NombrePagina:string = "Quines Somos";
}
