import { Router, RouterLink } from '@angular/router';
import { Component } from '@angular/core';
import { Profesor } from '../../../../interfaces/profesor.interface';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faTrashCan} from '@fortawesome/free-regular-svg-icons';
import { faPencil } from '@fortawesome/free-solid-svg-icons';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import {
  MatDialog,
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogTitle,
  MatDialogContent,
  MatDialogActions,
  MatDialogClose,
} from '@angular/material/dialog';
import { MatFabButton } from '@angular/material/button';

@Component({
  selector: 'app-profesores-panel',
  standalone: true,
  imports: [RouterLink, FontAwesomeModule],
  templateUrl: './profesores-panel.component.html',
  styleUrl: './profesores-panel.component.css'
})
export class ProfesoresPanelComponent {

  iconoBorrar = faTrashCan
  iconoModificar = faPencil
  iconoAnadir = faPlus
  
  public profesores:Profesor [] = []

  constructor(private servicio:AdminServicioService, private ruta:Router,
     private snackBar: MatSnackBar,private dialog: MatDialog){
  }

  async ngOnInit(){
      this.profesores = await this.servicio.getProfesores()
  }

  async BorrarProfesor(event:any,id: number) {

    if(confirm("Quieres borrar este Profesor")){
      event.target.innerText = "Borrar..."
      await this.servicio.borrarProfesore(id).then((r) =>{
        this.snackBar.open("Ha borrado el Profesor con exito!!", "Cerrar", {duration:5000});
        window.location.reload()
        return r;
      }).catch((error) =>{
        this.snackBar.open("Fallo en servicor" + error, "Cerrar", {duration:5000});
      })

    }
  }




}

