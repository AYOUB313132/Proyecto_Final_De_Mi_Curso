import { ImageURLPipe } from './../../../Pipes/image-url.pipe';
import { Component } from '@angular/core';
import { HeaderComunesPaginasComponent } from "../header-comunes-paginas/header-comunes-paginas.component";
import { Usuario } from '../../../interfaces/usuario.interface';
import { AdminServicioService } from '../../../servicios/servicio-admin/admin-servicio.service';
import { Profesor } from '../../../interfaces/profesor.interface';
import { ListaProfesoresComponent } from "../../lista-profesores/lista-profesores.component";


@Component({
    selector: 'app-profesores',
    standalone: true,
    templateUrl: './profesores.component.html',
    styles: ``,
    imports: [HeaderComunesPaginasComponent, ImageURLPipe, ListaProfesoresComponent]
})
export class ProfesoresComponent {

   NombrePagina:string = "Profesores";

  constructor(private servicioAdmin: AdminServicioService){}

  public profesores: Profesor[] = []
  linkPhoto:string = "D:/guardarImages/";

  async ngOnInit(){
      this.profesores = await this.servicioAdmin.getProfesores()
  }

}
