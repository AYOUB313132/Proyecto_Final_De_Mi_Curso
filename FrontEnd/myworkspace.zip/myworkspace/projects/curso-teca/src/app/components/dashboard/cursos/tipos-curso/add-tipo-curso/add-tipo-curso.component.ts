import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';
import { AdminServicioService } from '../../../../../servicios/servicio-admin/admin-servicio.service';

@Component({
  selector: 'app-add-tipo-curso',
  standalone: true,
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: './add-tipo-curso.component.html',
  styleUrl: './add-tipo-curso.component.css'
})
export class AddTipoCursoComponent {

  formAddTipo: FormGroup;

  nombreImagen = '';
  img!:File

  constructor(private servicio:AdminServicioService, private snackBar:MatSnackBar, private ruta:Router){
    this.formAddTipo = new FormGroup({
      'tipoNombre' : new FormControl('', Validators.required),
      'imagen' : new FormControl('')
    })
  }


  async addTipo(){
    if(this.formAddTipo.valid){



      //Añadir Tipo
      await this.servicio.addTipoCurso(
        this.formAddTipo.value).then( (res) =>{
           // Añadir imagen
      if(this.img){
        this.servicio.añadirImagen(this.img).subscribe( (res) =>{
          return res;
      })
      }
          this.snackBar.open("El Tipo ha añadido con exito!" ,"Cerrar", {duration:5000})
          this.ruta.navigateByUrl("/admin-dashboard")
          return res;
        }).catch((error) => {
          if(error.status === 409) {
              this.snackBar.open(error.error, "Error", {duration: 5000, panelClass: "error-snackbar"});
          } else {
              this.snackBar.open("Error del servidor", "Error", {duration: 5000, panelClass: "error-snackbar"});
          }
      });
    }
  }

 onSelectImg(event:any){
    this.img = event.target.files[0]
    this,this.nombreImagen = this.img.name

    this.formAddTipo.patchValue({
      imagen: this.img.name
    });
  }



}
