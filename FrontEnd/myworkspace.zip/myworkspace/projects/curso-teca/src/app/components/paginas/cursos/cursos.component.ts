import { Component } from '@angular/core';
import { HeaderComunesPaginasComponent } from "../header-comunes-paginas/header-comunes-paginas.component";
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Curso, Tipo } from '../../../interfaces/curso.interface';
import { AdminServicioService } from '../../../servicios/servicio-admin/admin-servicio.service';
import { ImageURLPipe } from './../../../Pipes/image-url.pipe';
import { ListaTipoCursosComponent } from "../../lista-tipo-cursos/lista-tipo-cursos.component";
import { ListaCursosComponent } from "../../lista-cursos/lista-cursos.component";

@Component({
    selector: 'app-cursos',
    standalone: true,
    templateUrl: './cursos.component.html',
    styles: ``,
    imports: [HeaderComunesPaginasComponent, ImageURLPipe, ListaTipoCursosComponent, ListaCursosComponent]
})
export class CursosComponent {

  NombrePagina:string = "Cursos";
  public cursos:Curso[] = []
  //public tiposCurso:Tipo[] = []
  public tiposCurso: { tipo: Tipo, numeroCursos: number }[] = [];

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {

  }

  async ngOnInit(){
    let allCursos = await this.servicio.getCursos().then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })
    this.cursos = allCursos.cursos

    try {
      const tipos = await this.servicio.getCursoTipos();
      const tiposConNumeros = await Promise.all(tipos.map(async (tipo: Tipo) => {
        const numeroCursos = await this.servicio.getNumeroCursosDeCadaTipo(tipo.tipoId);
        return { tipo, numeroCursos };
      }));
      this.tiposCurso = tiposConNumeros;
    } catch (error) {
      console.error('Error loading data', error);
}
  }



}
