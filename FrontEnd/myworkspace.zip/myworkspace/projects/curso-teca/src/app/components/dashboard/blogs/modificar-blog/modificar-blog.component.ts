import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Profesor } from '../../../../interfaces/profesor.interface';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { Blog, Categoria } from '../../../../interfaces/blog.interface';

@Component({
  selector: 'app-modificar-blog',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './modificar-blog.component.html',
  styleUrl: './modificar-blog.component.css'
})
export class ModificarBlogComponent {

  nombreImagen = '';
  img!: File

  formModificarBlog!: FormGroup;

  public blog!: Blog
  public categorias: Categoria[] = []
  public categoria!: Categoria
  //public categoriaID!: number

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {}

  async ngOnInit() {
    //Cargar Categorias
    this.categorias = await this.servicio.getCategorias();

    this.ruta.params.subscribe(async params => {
      const blogID = params['id'];

      this.blog = await this.servicio.getBlog(blogID).then((res) => {
        return  res;
      }).catch( (error) =>{
          return error;
      });
      console.log(this.blog)
      this.initializeForm();
    });
  }

  initializeForm() {
    this.formModificarBlog = new FormGroup({
      'titulo': new FormControl((this.blog ? this.blog.titulo : '')),
      'parrafo': new FormControl((this.blog ? this.blog.parrafo : '')),
      'descripcion': new FormControl((this.blog ? this.blog.descripcion : ''), Validators.required),
      'fecha': new FormControl((this.blog ? new Date(this.blog.fecha).toISOString().substring(0,10) : Validators.required)),
      'imagen': new FormControl((this.blog ? this.blog.imagen : '')),

      'categoria': new FormControl((this.blog ? this.blog.categoria : '', Validators.required)),
    });

    console.log(this.blog)
  }

  async modificarBlog(){

    this.categoria = await this.servicio.getCategoria(this.formModificarBlog.getRawValue().categoria)
    const blogConCategoria: Blog = {
      id: 0,
      titulo: this.formModificarBlog.getRawValue().titulo,
      parrafo: this.formModificarBlog.getRawValue().parrafo,
      descripcion: this.formModificarBlog.getRawValue().descripcion,
      fecha: this.formModificarBlog.getRawValue().fecha,
      categoria: this.categoria,
      imagen: (this.img) ? this.img.name : ' ',
    };

    console.log(" blogconCate: " +  blogConCategoria)

    await this.servicio.modificarBlog(this.blog.id, blogConCategoria)
      .then((res) => {
        this.snackBar.open("Ha modificado el Blog con exito!!", "Cerrar", {duration:5000});
        this.navigate.navigateByUrl("/admin-dashboard");
        return res;
      }).catch( (error) => {
        this.snackBar.open("Error Servidor","Bad Request" + error, {duration:5000,panelClass:"error-snackbar"})
      })

  }

  async onSelectImg(event: any) {
    this.img = event.target.files[0]
    this.formModificarBlog.patchValue({
      imagen: this.img.name
    });
  }

}
