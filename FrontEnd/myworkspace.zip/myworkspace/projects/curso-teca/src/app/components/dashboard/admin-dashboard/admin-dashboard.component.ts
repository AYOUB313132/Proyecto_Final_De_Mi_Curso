import { Component, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StorageService } from '../../../servicios/storage.service';
import { AdminServicioService } from '../../../servicios/servicio-admin/admin-servicio.service';
import { SidbarComponent } from "../sidbar/sidbar.component";
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faClose } from '@fortawesome/free-solid-svg-icons';
import { faHome } from '@fortawesome/free-solid-svg-icons';
import { UsuariosPanelComponent } from "../usuarios/usuarios-panel/usuarios-panel.component";
import { CursosPanelComponent } from "../cursos/cursos-panel/cursos-panel.component";
import { ProfesoresPanelComponent } from "../profesores/profesores-panel/profesores-panel.component";
import { TipoCursoPanelComponent } from "../cursos/tipos-curso/tipo-curso-panel/tipo-curso-panel.component";
import { BlogPanelComponent } from "../blogs/blog-panel/blog-panel.component";

@Component({
    selector: 'app-admin-dashboard',
    standalone: true,
    templateUrl: './admin-dashboard.component.html',
    styleUrl: './admin-dashboard.component.css',
    imports: [SidbarComponent, FontAwesomeModule, UsuariosPanelComponent, CursosPanelComponent, ProfesoresPanelComponent, TipoCursoPanelComponent, BlogPanelComponent]
})
export class AdminDashboardComponent {


  constructor(private servicio:AdminServicioService,
    private http:HttpClient, private storage: StorageService){}

  /* =============== SidBar =============== */



   /* =============== Body =============== */

  usuarios:boolean = true
  profesores:boolean = true
  cursos:boolean = true
  tipos:boolean = true
  general:boolean = false
  blogs:boolean = true

  showGeneral(){
    this.general = false
    this.profesores = true
    this.cursos = true
    this.usuarios = true
    this.blogs = true
  }

  showUsuariosPanel(){
    this.profesores = true
    this.cursos = true
    this.general = true
    this.tipos = true
    this.usuarios = false
    this.blogs = true
  }

  showProfesoresPanel(){
    this.usuarios = true
    this.cursos = true
    this.general = true
    this.tipos = true
    this.profesores = false
    this.blogs = true
  }

  showCursosPanel(){
    this.profesores = true
    this.usuarios = true
    this.general = true
    this.tipos = true
    this.cursos = !this.cursos
    this.blogs = true
  }

  showTiposPanel() {
    this.profesores = true
    this.usuarios = true
    this.general = true
    this.tipos = !this.tipos
    this.cursos = true
    this.blogs = true
    }

  showBlogs(){
    this.usuarios = true
    this.cursos = true
    this.general = true
    this.tipos = true
    this.profesores = true
    this.blogs = false
  }

  ngOnInit(){

  }

}
