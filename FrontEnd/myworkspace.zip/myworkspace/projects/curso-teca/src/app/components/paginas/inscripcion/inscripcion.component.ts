import { Component } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { HeaderComunesPaginasComponent } from "../header-comunes-paginas/header-comunes-paginas.component";
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSnackBar} from '@angular/material/snack-bar';
import { AuthServiceService } from '../../../servicios/auth-service.service';
import { AdminServicioService } from '../../../servicios/servicio-admin/admin-servicio.service';

@Component({
    selector: 'app-inscripcion',
    standalone: true,
    templateUrl: './inscripcion.component.html',
    styles: ``,
    imports: [RouterLink, HeaderComunesPaginasComponent, ReactiveFormsModule,MatSlideToggleModule,MatIconModule,MatFormFieldModule,MatInputModule,MatButtonModule]
})
export class InscripcionComponent {

  hidePassword:boolean = true;

  formRegistracion: FormGroup;

  nombreImagen = '';
  img!:File


  constructor(private snackbar:MatSnackBar, private authService: AuthServiceService,
     private ruta:Router, private servicio:AdminServicioService){
    this.formRegistracion = new FormGroup({
      'nombre' : new FormControl('', Validators.required),
      'apellido' : new FormControl('', Validators.required),
      'fechaNacimiento' : new FormControl('', Validators.required),
      'email' : new FormControl('', [Validators.required, Validators.email]),
      'movil' : new FormControl('', [Validators.required, Validators.minLength(9), Validators.maxLength(9)]),
      'genero' : new FormControl('', Validators.required),
      'contraseña' : new FormControl('', Validators.required),
      'confirmContraseña' : new FormControl('', Validators.required),
      'imagen' : new FormControl('')
    })
  }



  async registrar() {
    console.log(this.formRegistracion.valid)

    const contraseña = this.formRegistracion.get("contraseña")?.value;
    const confirmContraseña = this.formRegistracion.get("confirmContraseña")?.value;

    if(contraseña !== confirmContraseña){
      this.snackbar.open("Contraseña not igual", "Close", {duration:5000,panelClass:"error-snackbar"});
      return;
    }

     // Añadir imagen
     if(this.img){
      this.nombreImagen = this.img.name
      this.servicio.añadirImagen(this.img).subscribe( (res) =>{
        return res;
    })
    }

    await this.authService.register(this.formRegistracion.value).then((res) => {
      console.log(res);

        this.snackbar.open(res.message, "Close", {duration:5000});
        this.ruta.navigateByUrl("/login");
      }).catch( (error) =>{
        this.snackbar.open("Registacion faild, Try again" + error.error, "Close", {duration:5000,panelClass:"error-snackbar"});
      })

  }


  onSelectImg(event:any){
    this.img = event.target.files[0]
    console.log(this.img.name)
    this.formRegistracion.patchValue({
      imagen: this.img.name
    });
  }

}
