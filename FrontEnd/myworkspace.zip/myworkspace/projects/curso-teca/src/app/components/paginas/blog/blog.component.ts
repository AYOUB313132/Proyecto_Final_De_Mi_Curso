import { Component } from '@angular/core';
import { HeaderComunesPaginasComponent } from "../header-comunes-paginas/header-comunes-paginas.component";
import { Blog } from '../../../interfaces/blog.interface';
import { AdminServicioService } from '../../../servicios/servicio-admin/admin-servicio.service';
import { DatePipe } from '@angular/common';
import { ListaBlogsComponent } from "../../lista-blogs/lista-blogs.component";
import { Tipo } from '../../../interfaces/curso.interface';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-blog',
    standalone: true,
    templateUrl: './blog.component.html',
    styles: ``,
    imports: [DatePipe, HeaderComunesPaginasComponent, ListaBlogsComponent, RouterLink]
})
export class BlogComponent {

  NombrePagina:string = "Blog";
  public blogs: Blog[] = []
  //public tiposCurso:Tipo[] = []
  tiposCurso: { tipo: Tipo, numeroCursos: number }[] = [];

  constructor(private servicioAdmin: AdminServicioService){}

  async ngOnInit(){

    this.blogs = await this.servicioAdmin.getBlogs().then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })

    /*
    this.tiposCurso = await this.servicioAdmin.getCursoTipos().then( (response) =>{
      return response;
    }).catch( (error) =>{
      return error;
    })
    */

    try {
      const tipos = await this.servicioAdmin.getCursoTipos();
      const tiposConNumeros = await Promise.all(tipos.map(async (tipo: Tipo) => {
        const numeroCursos = await this.servicioAdmin.getNumeroCursosDeCadaTipo(tipo.tipoId);
        return { tipo, numeroCursos };
      }));
      this.tiposCurso = tiposConNumeros;
    } catch (error) {
      console.error('Error loading data', error);
}
}

}
