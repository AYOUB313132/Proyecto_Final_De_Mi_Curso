import { Component } from '@angular/core';
import { HeaderComunesPaginasComponent } from "../header-comunes-paginas/header-comunes-paginas.component";

@Component({
    selector: 'app-contacto',
    standalone: true,
    templateUrl: './contacto.component.html',
    styles: ``,
    imports: [HeaderComunesPaginasComponent]
})
export class ContactoComponent {

  NombrePagina:string = "Contacto";
}
