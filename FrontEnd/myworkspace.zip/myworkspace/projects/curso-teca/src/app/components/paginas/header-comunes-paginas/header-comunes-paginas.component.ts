import { Component, Input } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-header-comunes-paginas',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './header-comunes-paginas.component.html',
  styles: ``
})
export class HeaderComunesPaginasComponent {

   @Input()  NombrePagina:string = ""

}
