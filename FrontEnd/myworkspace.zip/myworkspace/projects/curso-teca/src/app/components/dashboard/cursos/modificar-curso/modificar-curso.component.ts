import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Profesor } from '../../../../interfaces/profesor.interface';
import { AdminServicioService } from '../../../../servicios/servicio-admin/admin-servicio.service';
import { Curso, Tipo } from '../../../../interfaces/curso.interface';

@Component({
  selector: 'app-modificar-curso',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './modificar-curso.component.html',
  styleUrl: './modificar-curso.component.css'
})
export class ModificarCursoComponent {

  nombreImagen = '';
  img!: File
  formModificarCurso!: FormGroup;
  public curso!: Curso
  public tipoCurso!:Tipo
  public TiposDeCurso:Tipo [] = []
  public profesores:Profesor[] = []
  public profesor!:Profesor
  public profesorID!:number

  constructor(private servicio: AdminServicioService, private snackBar: MatSnackBar, private ruta: ActivatedRoute, private navigate:Router) {}

  async ngOnInit() {

    // Cargar la lista de TiposCurso
    this.TiposDeCurso= await this.servicio.getCursoTipos();

    // Cargar la lista de Profesores
      this.profesores = await this.servicio.getProfesores()

    this.ruta.params.subscribe(async params => {
      const cursoId = params['id'];
      this.curso = await this.servicio.getCurso(cursoId).then((res) => {
        return  res;
      }).catch( (error) =>{
          return error;
      });

      this.initializeForm();
    });
  }

  initializeForm() {
    this.formModificarCurso = new FormGroup({
      'nombreCurso': new FormControl((this.curso ? this.curso.nombreCurso : ''), Validators.required),
      'detallesDelCurso': new FormControl((this.curso ? this.curso.detallesDelCurso : ''), Validators.required),
      'fechaInicio': new FormControl((this.curso ? new Date(this.curso.fechaInicio).toISOString().substring(0,10) : Validators.required)),
      'fechaFinal': new FormControl((this.curso ?  new Date(this.curso.fechaFinal).toISOString().substring(0,10) : Validators.required)),
      'tipo': new FormControl((this.curso ? this.curso.tipo : '')),
      'precio': new FormControl((this.curso ? this.curso.precio : '')),
      'profesor': new FormControl((this.curso ? this.curso.profesorId : '')),
      'imagen': new FormControl((this.curso ? this.curso.imagen : '')),
    });
  }

  async modificarCurso(){
    const diaHoy = new Date().getTime()

    this.profesor = await this.servicio.getProfesore(this.formModificarCurso.getRawValue().profesor)

    this.tipoCurso = await this.servicio.getCursoTipo(this.formModificarCurso.getRawValue().tipo)

    const cursoConTipo: Curso = {
      cursoId: 0,
      nombreCurso: this.formModificarCurso.getRawValue().nombreCurso,
      detallesDelCurso: this.formModificarCurso.getRawValue().detallesDelCurso,
      fechaInicio: this.formModificarCurso.getRawValue().fechaInicio,
      fechaFinal: this.formModificarCurso.getRawValue().fechaFinal,
      profesorId: this.profesor.id,
      precio: this.formModificarCurso.getRawValue().precio,
      tipo: this.tipoCurso,
      imagen: (this.img)? this.img.name:'',
  };

    const fInicio = new Date (this.formModificarCurso.getRawValue().fechaInicio ).getTime()
    const fFinal = new Date (this.formModificarCurso.getRawValue().fechaFinal ).getTime()

    if(fFinal > fInicio && fInicio > diaHoy){
      // Añadir imagen
    if(this.img){
      this.nombreImagen = this.img.name
      this.servicio.añadirImagen(this.img).subscribe( (res) =>{
    })
    }

    await this.servicio.modificarCurso(this.curso.cursoId, cursoConTipo)
      .then((res) => {
        this.snackBar.open("Ha modificado el Curso con exito!!", "Cerrar", {duration:5000});
        this.navigate.navigateByUrl("/cursos");
        return res;
      }).catch( (error) => {
        this.snackBar.open("Error Servidor","Bad Request" + error, {duration:5000,panelClass:"error-snackbar"})
      })
    }
  }


  async onSelectImg(event: any) {
    this.img = event.target.files[0]
    this.formModificarCurso.patchValue({
      imagen: this.img.name
    });
  }
}
