import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { importProvidersFrom } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

bootstrapApplication(AppComponent, {
  providers: [
    appConfig.providers,
    importProvidersFrom(HttpClientModule,RouterModule,ActivatedRoute), provideAnimationsAsync(), provideAnimationsAsync(), provideAnimationsAsync(),
  ]
}
)
  .catch((err) => console.error(err));
