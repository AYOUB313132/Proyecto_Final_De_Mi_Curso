export const environment = {
  production: true,
  apiUrl: 'http://localhost:8094ng build --configuration=staging'
};
